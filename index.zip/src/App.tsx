import { useState } from "react";
import { Home } from "./components/Home";
import { ReportScreen } from "./components/ReportScreen";
import { ExploreScreen } from "./components/ExploreScreen";
import { SavedScreen } from "./components/SavedScreen";
import { ProfileScreen } from "./components/ProfileScreen";
import { CulturalTipsScreen } from "./components/CulturalTipsScreen";
import { LoginModal } from "./components/LoginModal";
import { SignUpModal } from "./components/SignUpModal";
import ScreenLoader from "./components/ScreenLoader";

type Screen =
  | "home"
  | "explore"
  | "report"
  | "saved"
  | "profile"
  | "cultural";

const MIN_LOADING_TIME = 1000; // 1 second

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home");
  const [isScreenLoading, setIsScreenLoading] = useState(false);

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showSignUpModal, setShowSignUpModal] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  /* ---------------- AUTH ---------------- */

  const handleLogin = (name: string) => {
    setUserName(name);
    setIsLoggedIn(true);
    setShowLoginModal(false);
  };

  const handleSignUp = (name: string) => {
    setUserName(name);
    setIsLoggedIn(true);
    setShowSignUpModal(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserName("");
    handleNavigate("home");
  };

  /* ---------------- NAVIGATION (NO BLANKING) ---------------- */

  const handleNavigate = (screen: Screen) => {
    if (screen === currentScreen) return;

    setIsScreenLoading(true);

    setTimeout(() => {
      setCurrentScreen(screen);
      setIsScreenLoading(false);
    }, MIN_LOADING_TIME);
  };

  /* ---------------- SCREEN RENDER ---------------- */

  const renderScreen = () => {
    const commonProps = {
      onNavigate: handleNavigate,
      isLoggedIn,
      userName,
      onShowLogin: () => setShowLoginModal(true),
      onLogout: handleLogout,
      isDarkMode,
      onToggleDarkMode: setIsDarkMode,
    };

    switch (currentScreen) {
      case "home":
        return <Home {...commonProps} />;
      case "explore":
        return <ExploreScreen {...commonProps} />;
      case "report":
        return <ReportScreen {...commonProps} />;
      case "saved":
        return <SavedScreen {...commonProps} />;
      case "profile":
        return <ProfileScreen {...commonProps} />;
      case "cultural":
        return <CulturalTipsScreen {...commonProps} />;
      default:
        return <Home {...commonProps} />;
    }
  };

  /* ---------------- UI ---------------- */

  return (
    <div
      className={`relative min-h-screen transition-colors ${
        isDarkMode
          ? "bg-gray-900"
          : "bg-gradient-to-br from-orange-50 via-white to-green-50"
      }`}
    >
      {/* ✅ ALWAYS render screen */}
      {renderScreen()}

      {/* ✅ Loader overlays on top, does NOT replace content */}
      <ScreenLoader visible={isScreenLoading} />

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLogin={handleLogin}
        onShowSignUp={() => {
          setShowLoginModal(false);
          setShowSignUpModal(true);
        }}
        isDarkMode={isDarkMode}
      />

      <SignUpModal
        isOpen={showSignUpModal}
        onClose={() => setShowSignUpModal(false)}
        onSignUp={handleSignUp}
        isDarkMode={isDarkMode}
      />
    </div>
  );
}
