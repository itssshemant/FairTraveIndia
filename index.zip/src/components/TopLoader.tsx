import { useEffect, useState } from "react";

interface TopLoaderProps {
  isLoading: boolean;
}

export default function TopLoader({ isLoading }: TopLoaderProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (isLoading) {
      setVisible(true);
    } else {
      // fade out after loading ends
      const timeout = setTimeout(() => setVisible(false), 400);
      return () => clearTimeout(timeout);
    }
  }, [isLoading]);

  if (!visible) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[9999] h-1 bg-transparent">
      <div
        className={`h-full bg-gradient-to-r from-orange-500 via-amber-500 to-green-500 transition-all duration-500 ${
          isLoading ? "w-2/3 opacity-100" : "w-full opacity-0"
        }`}
      />
    </div>
  );
}
